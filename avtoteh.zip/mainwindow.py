import customtkinter
from tkinter import *
from tkinter import ttk
import tkinter as tk
from tkinter import messagebox
import database
import cumpara_screen




def mainwindow():
    app=customtkinter.CTk()
    app.title('Avtoteh')
    app.geometry('920x420')
    app.config(bg='#16161a')
    app.resizable(False,False)
    
    font1 = ('Helvetica', 20, 'bold')
    font2 = ('Arial', 13, 'bold')

    
    def add_to_treeview():
        piese= database.fetch_piese()
        tree.delete(*tree.get_children())
        for piese in piese:
            tree.insert("",END,values=piese)
                        
        
    def clear(*clicked):
        if clicked:
            tree.selection_remove(tree.focus())
        id_entry.delete(0,END)
        name_entry.delete(0,END)
        marca_entry.delete(0,END)
        model_entry.delete(0,END)
        status_entry.delete(0,END)
        
    def display_data(event):
        selected_item=tree.focus()
        if selected_item:
            row=tree.item(selected_item)['values']
            clear()
            id_entry.insert(0,row[0])
            name_entry.insert(0,row[1])
            marca_entry.insert(0,row[2])
            model_entry.insert(0,row[3])
            status_entry.insert(0,row[4])
        else:
            pass
           
    def insert():
        id= id_entry.get()
        name=name_entry.get()
        marca=marca_entry.get()
        model=model_entry.get()
        status=status_entry.get()
        if not (id and name and marca and model and status):
            messagebox.showerror("error","introdu varu tot")
        elif database.id_exists(id):
            messagebox.showerror('error','exista id u sefule')
        else:
            database.insert_piese(id,name,marca,model,status)
            add_to_treeview()
            clear()
            messagebox.showinfo('success','direct pe publi')
            
    def delete():
        selected_item=tree.focus()
        if not selected_item:
            messagebox.showerror('error','chose an piesa to delete')
        else:
            id=id_entry.get()
            database.delete_piese(id)
            add_to_treeview()
            clear()
            messagebox.showinfo('success','ai sters tot sa moara ')
            
    def update():
        selected_item=tree.focus()
        if not selected_item:
            messagebox.showerror("error",'alege o piesa pentru a face asta')
        else:
            id=id_entry.get()
            name=name_entry.get()
            marca=marca_entry.get()
            model=model_entry.get()
            status=status_entry.get()
            database.update_piese(name,marca,model,status,id)
            add_to_treeview()
            clear() 
            messagebox.showinfo('success', 'ai facut conversia pornista')
    
    id_label = customtkinter.CTkLabel(app,font=font1,text='ID:',text_color='#fffffe',bg_color='#16161a')
    id_label.place(x=45,y=20)
    
    id_entry = customtkinter.CTkEntry(app,font=font1,text_color='#fffffe',fg_color='#72757e',border_color='#7f5af0',border_width=2,width=180)
    id_entry.place(x=100,y=20)
    
    name_label = customtkinter.CTkLabel(app,font=font1,text='Nume:',text_color='#fffffe',bg_color='#16161a')
    name_label.place(x=20,y=80)
    
    name_entry = customtkinter.CTkEntry(app,font=font1,text_color='#fffffe',fg_color='#72757e',border_color='#7f5af0',border_width=2,width=180)
    name_entry.place(x=100,y=80)
    
    marca_label = customtkinter.CTkLabel(app,font=font1,text='Marca:',text_color='#fffffe',bg_color='#16161a')
    marca_label.place(x=20,y=140)
    
    marca_entry = customtkinter.CTkEntry(app,font=font1,text_color='#fffffe',fg_color='#72757e',border_color='#7f5af0',border_width=2,width=180)
    marca_entry.place(x=100,y=140)
    
    model_label = customtkinter.CTkLabel(app,font=font1,text='Model:',text_color='#fffffe',bg_color='#16161a')
    model_label.place(x=20,y=200)
    
    model_entry = customtkinter.CTkEntry(app,font=font1,text_color='#fffffe',fg_color='#72757e',border_color='#7f5af0',border_width=2,width=180)
    model_entry.place(x=100,y=200)
    
    status_label = customtkinter.CTkLabel(app,font=font1,text='Status:',text_color='#fffffe',bg_color='#16161a')
    status_label.place(x=20,y=260)
    
    status_entry = customtkinter.CTkEntry(app,font=font1,text_color='#fffffe',fg_color='#72757e',border_color='#7f5af0',border_width=2,width=180)
    status_entry.place(x=100,y=260)
    
    add_button=customtkinter.CTkButton(app,command=insert,font=font1,text_color='#fffffe',text='Adauga anunt',fg_color='#7f5af0',bg_color='#16161a',cursor='hand2',corner_radius=15,width=260)
    add_button.place(x=20,y=310)
    
    
    
    clear_button=customtkinter.CTkButton(app,command=lambda:clear(True),font=font1,text_color='#fffffe',text='Anunt nou',fg_color='#2cb67d',bg_color='#16161a',cursor='hand2',corner_radius=15,width=260)
    clear_button.place(x=20,y=360)
    
    update_button=customtkinter.CTkButton(app,command=update,font=font1,text_color='#fffffe',text='Editeaza anunt',fg_color='#7f5af0',bg_color='#16161a',cursor='hand2',corner_radius=15,width=260)
    update_button.place(x=300,y=360)
    
    delete_button=customtkinter.CTkButton(app,command=delete,font=font1,text_color='#fffffe',text='Sterge anunt',fg_color='#2cb67d',bg_color='#16161a',cursor='hand2',corner_radius=15,width=140)
    delete_button.place(x=580,y=360)
    
    cumpara=customtkinter.CTkButton(app,command=cumpara,font=font1,text_color='#fffffe',text='Cumpara',fg_color='#7f5af0',bg_color='#16161a',cursor='hand2',corner_radius=15,width=140)
    cumpara.place(x=750,y=360)
    
    style = ttk.Style(app)
    style.theme_use('clam')
    style.configure('Treeview',font=font2,foreground='#7f5af0',background='#94a1b2',fieldbackground='#94a1b2')
    style.map('Treeview',background=[('selected','#7f5af0')])
    
    tree= ttk.Treeview(app,height=15)
    
    tree['columns']=('ID','Name','Marca','Model','Status')
    
    tree.column('#0',width=0,stretch=tk.NO)
    tree.column('ID',anchor=tk.CENTER,width=120)
    tree.column('Name',anchor=tk.CENTER,width=120)
    tree.column('Marca',anchor=tk.CENTER,width=120)
    tree.column('Model',anchor=tk.CENTER,width=120)
    tree.column('Status',anchor=tk.CENTER,width=120)
    
    tree.heading('ID',text='ID')
    tree.heading('Name',text='Nume')
    tree.heading('Marca',text='Marca')
    tree.heading('Model',text='Model')
    tree.heading('Status',text='Status')
    tree.place(x=300,y=20)
    
    add_to_treeview()
    
    tree.bind('<ButtonRelease>', display_data)
        

    app.mainloop()
mainwindow()