import customtkinter as ctk
from tkinter import *
from tkinter import ttk
import tkinter as tk
from tkinter import messagebox

def cumpara():
    cumpara=ctk.CTk()
    cumpara.title("promit ca nu ti fur datele de pe card :333333333")
    cumpara.geometry("470x600")
    cumpara.config(bg='#16161a')
    
    font1 = ('Helvetica', 18, 'bold')
    font2 = ('Arial', 13, 'bold')
    
    name_label = ctk.CTkLabel(cumpara,font=font1,text='Nume:',text_color='#fffffe',bg_color='#16161a')
    name_label.place(x=39,y=80)
    
    name_entry =ctk.CTkEntry(cumpara,font=font1,text_color='#fffffe',fg_color='#72757e',border_color='#7f5af0',border_width=2,width=350)
    name_entry.place(x=100,y=80)
    
    prenume_label = ctk.CTkLabel(cumpara,font=font1,text='Prenume:',text_color='#fffffe',bg_color='#16161a')
    prenume_label.place(x=11,y=120)
    
    prenume_entry =ctk.CTkEntry(cumpara,font=font1,text_color='#fffffe',fg_color='#72757e',border_color='#7f5af0',border_width=2,width=350)
    prenume_entry.place(x=100,y=120)
    
    
    adresa_label = ctk.CTkLabel(cumpara,font=font1,text='Adresa:',text_color='#fffffe',bg_color='#16161a')
    adresa_label.place(x=20,y=160)
    
    adresa_entry =ctk.CTkEntry(cumpara,font=font1,text_color='#fffffe',fg_color='#72757e',border_color='#7f5af0',border_width=2,width=350)
    adresa_entry.place(x=100,y=160)
    
    
    
    
    
    
    cumpara.mainloop()
    
    
cumpara()